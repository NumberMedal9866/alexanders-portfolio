<template>
  <Navbar/>
  <RouterView/>
  <Footer/>
  <div class="effect">
    <div id="blob"></div>
  </div>
</template>

<script setup>
import Navbar from './components/Navbar/Navbar.vue';
import Footer from './components/Footer/Footer.vue';


// const blob = document.getElementById("blob")
// document.body.onpointermove =  event =>{
//     const {clientX, clientY} = event;

//     blob.animate({
//         left: `${clientX}px`,
//         top : `${clientY}px`
//     },{duration: 10000, fill: "forwards"});
// }
</script>



<style lang="scss" scoped>
  #blob {
    background: linear-gradient(
        to right,
        #3F64E96E,
        #E93F3F6E,
        #FFB8006E
    );
    height: 500px;
    aspect-ratio: 1.5;
    position: absolute;
    left: 50%;
    top: 50%;
    translate: -50% -50%;
    border-radius: 50%;
    animation: rotate 20s infinite;
    filter: blur(100px);
    z-index: -999;
}
.effect{
    z-index: -999;
}


@keyframes rotate {
    from{
        rotate: 0deg;
    }
    50%{
        scale: 1 1.25;
    }
    to{
        rotate: 360deg;
    }
}
</style>