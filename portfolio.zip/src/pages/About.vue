<template>
    <div class="sf">
        sfsfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdsfsdfsdf
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>
    .sf{
        width: 100%;
        color: green;
    }
</style>