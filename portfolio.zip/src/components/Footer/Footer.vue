<template>
    <footer class="footer">
        <div class="container">
            <div class="footer-holder">
                <div class="footer-logo">
                    <img src="@/assets/images/logo-no-background.svg" alt="">
                    <span>© 2023 Tsoy Alexander. All Rights Reserved.</span>
                </div>
                <div class="footer-ul">
                    <ul>
                        <li class="first">Links</li>
                        <router-link to="/">About</router-link>
                        <router-link to="/">Work</router-link>
                        <router-link to="/">Tech Stack</router-link>
                        <router-link to="/">Contact</router-link>
                    </ul>
                    <ul>
                        <li class="first">Elsewhere</li>
                        <li><a href="#">Email</a></li>
                        <li><a href="#">LinkedIn</a></li>
                        <li><a href="#">GitHub</a></li>
                        <li><a href="#">Twitter</a></li>
                        <li><a href="#">Discord</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- <img src="@/assets/image/blur.png" alt="" class="blurry"> -->
    </footer>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>